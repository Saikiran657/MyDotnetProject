﻿using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.Models;
using System.Collections.Generic;

namespace ComicBookCart_Master.DataAccessLAyer
{
    public class ComicBookDbContext :DbContext
    {
            public ComicBookDbContext(DbContextOptions<ComicBookDbContext> options) : base(options) { }
            public DbSet<Comics> Comics { get; set; }
            public DbSet<Artist> Artist { get; set; }
            public DbSet<Account> Account { get; set; }

            public DbSet<Order> Order { get; set; }
            public DbSet<Payment> Payment { get; set; }
            public DbSet<UserData> UserData { get; set; }
    }
}
