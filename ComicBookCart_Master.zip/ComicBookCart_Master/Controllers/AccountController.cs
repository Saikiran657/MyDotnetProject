﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ComicBookCart_Master.Repository;
using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountRepository _Account;
        public AccountController(IAccountRepository Account)
        {
            _Account = Account;
        }

        [HttpGet]
        [Route("GetAccountDetails")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Account.GetAccountDetails());
        }

        [HttpGet]
        [Route("GetAccountByID/{CustomerID}")]
        public async Task<IActionResult> GetAccountByID(int CustomerID)
        {
            return Ok(await _Account.GetAccountByID(CustomerID));
        }


        [HttpPost]
        [Route("Add")]
        public async Task<IActionResult> Post(Account Acc)
        {
            var result = await _Account.InsertAccount(Acc);
            if (result.CustomerID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }


        [HttpPut]
        [Route("Update")]
        public async Task<IActionResult> Put(Account Acc)
        {
            await _Account.UpdateAccount(Acc);
            return Ok("Updated Successfully");
        }


        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteAccount")]
        public JsonResult Delete(int CustomerID)
        {
            _Account.DeleteAccount(CustomerID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
