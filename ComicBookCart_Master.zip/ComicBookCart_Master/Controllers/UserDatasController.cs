﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.DataAccessLAyer;
using ComicBookCart_Master.Models;

namespace project11_Online_Comic_Book_Store.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserDatasController : ControllerBase
    {
        //[HttpGet]
        //[Route("Getuser")]
        //public async Task<IActionResult> Get()
        //{
        //    return Ok(await .GetComics());
        //}
    }
}