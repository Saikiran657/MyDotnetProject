﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ComicBookCart_Master.Models;
using ComicBookCart_Master.Repository;

namespace ComicBookCart_Master.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistsController : ControllerBase
    {
        private readonly IArtistRepository _Artist;
        private readonly IComicRepository _Comics;
        public ArtistsController(IArtistRepository Artist, IComicRepository Comics)
        {
            _Artist = Artist;
            _Comics = Comics;
            //throw new ArgumentNullException(nameof(Comics));
        }
        [HttpGet]
        [Route("GetArtist")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Artist.GetArtist());
        }


        [HttpGet]
        [Route("GetArtistsByID/{Id}")]
        public async Task<IActionResult> GetArtistByID(int ArtistId)
        {
            return Ok(await _Artist.GetArtistByID(ArtistId));
        }


        [HttpPost]
        [Route("AddArtist")]
        public async Task<IActionResult> Post(Artist Art)
        {
            var result = await _Artist.InsertArtist(Art);
            if (result.ArtistID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }

        [HttpPut]
        [Route("UpdateArtist")]
        public async Task<IActionResult> Put(Artist Art)
        {
            await _Artist.UpdateArtist(Art);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteArtists")]
        public JsonResult Delete(int ArtistID)
        {
            _Artist.DeleteArtist(ArtistID);
            return new JsonResult("Deleted Successfully");
        }
        [HttpGet]
        [Route("GetAllComics")]
        public async Task<IActionResult> GetAllComics()
        {
            return Ok(await _Comics.GetComics());
        }
    }
}
