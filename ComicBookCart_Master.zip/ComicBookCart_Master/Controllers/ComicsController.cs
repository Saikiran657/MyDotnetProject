using Microsoft.AspNetCore.Mvc;
using ComicBookCart_Master.Repository;
using ComicBookCart_Master.Models;

namespace project11_Online_Comic_Book_Store.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ComicsController : ControllerBase
    {
        private readonly IComicRepository _Comics;
        //private readonly ILogger<> _logger;
        public ComicsController(IComicRepository Comics)
        {
            _Comics = Comics;
                //throw new ArgumentNullException(nameof(Comics));
        }

        [HttpGet]
        [Route("GetComics")]
        public async Task<IActionResult> Get()
        {
           return Ok(await _Comics.GetComics());
        }


        [HttpGet]
        [Route("GetComicsByID/{Id}")]
        public async Task<IActionResult> GetDeptById(int Id)
        {
            return Ok(await _Comics.GetComicsByID(Id));
        }


        [HttpPost]
        [Route("AddComics")]
        public async Task<IActionResult> Post(Comics com)
        {
            var result = await _Comics.InsertComics(com);
            if (result.ID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }

        [HttpPut]
        [Route("UpdateComics")]
        public async Task<IActionResult> Put(Comics com)
        {
            await _Comics.UpdateComics(com);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteComics")]
        public JsonResult Delete(int ID)
        {
            _Comics.DeleteComics(ID);
            return new JsonResult("Deleted Successfully");
        }
    }
}