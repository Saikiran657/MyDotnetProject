﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ComicBookCart_Master.Models;
using ComicBookCart_Master.Repository;

namespace ComicBookCart_Master.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentRepository _Payments;
        //private readonly ILogger<> _logger;
        public PaymentController(IPaymentRepository Payment)
        {
            _Payments = Payment;
           
        }

        [HttpGet]
        [Route("GetPayments")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Payments.GetPayments());
        }


        [HttpGet]
        [Route("GetPaymentByID/{Id}")]
        public async Task<IActionResult> GetPaymentById(int PaymentId)
        {
            return Ok(await _Payments.GetPaymentByID(PaymentId));
        }


        [HttpPost]
        [Route("AddPayments")]
        public async Task<IActionResult> Post(Payment pay)
        {
            var result = await _Payments.InsertPayment(pay);
            if (result.PaymentID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }

        [HttpPut]
        [Route("Update Payments")]
        public async Task<IActionResult> Put(Payment pay)
        {
            await _Payments.UpdatePayment(pay);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
       
        [Route("Delete Payments")]
        public JsonResult Delete(int PaymentID)
        {
            _Payments.DeletePayment(PaymentID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
