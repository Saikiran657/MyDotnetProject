﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ComicBookCart_Master.Repository;
using ComicBookCart_Master.Models;


namespace ComicBookCart_Master.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _Order;
        //private readonly ILogger<> _logger;
        public OrderController(IOrderRepository Order)
        {
            _Order = Order;
            //throw new ArgumentNullException(nameof(Comics));
        }

        [HttpGet]
        [Route("GetOrders")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _Order.GetOrders());
        }


        [HttpGet]
        [Route("GetOrderByID/{Id}")]
        public async Task<IActionResult> GetOrderById(int OrderID)
        {
            return Ok(await _Order.GetOrderByID(OrderID));
        }


        [HttpPost]
        [Route("AddOrder")]
        public async Task<IActionResult> Post(Order Ord)
        {
            var result = await _Order.InsertOrder(Ord);
            if (result.OrderID == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Successfully");
        }

        [HttpPut]
        [Route("UpdateOrder")]
        public async Task<IActionResult> Put(Order Ord)
        {
            await _Order.UpdateOrder(Ord);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteOrder")]
        public JsonResult Delete(int OrderID)
        {
            _Order.DeleteOrder(OrderID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
