﻿using System.ComponentModel.DataAnnotations;

namespace ComicBookCart_Master.Models
{
    public class Artist
    {
        [Key]
        public int ArtistID { get; set; }
        public string ArtistName { get; set; }
       
        public string ArtistRole{ get; set; }
    }
}
