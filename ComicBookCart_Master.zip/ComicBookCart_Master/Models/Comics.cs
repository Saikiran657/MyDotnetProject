﻿using System.ComponentModel.DataAnnotations;

namespace ComicBookCart_Master.Models
{
    public class Comics
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public int Number_of_Episodes { get; set; }
        public string Series_Title { get; set; }
        public int ArtistID { get; set; }
    }
}
