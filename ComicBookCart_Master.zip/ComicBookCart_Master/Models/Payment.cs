﻿using System.ComponentModel.DataAnnotations;

namespace ComicBookCart_Master.Models
{
    public class Payment
    {
        [Key]
        public int PaymentID { get; set; }
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
       
    }
}
