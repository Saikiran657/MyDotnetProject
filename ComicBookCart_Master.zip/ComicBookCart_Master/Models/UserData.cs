﻿using System.ComponentModel.DataAnnotations;

namespace ComicBookCart_Master.Models
{
    public class UserData
    {
        [Key]
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }
}
