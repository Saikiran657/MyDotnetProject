﻿using System.ComponentModel.DataAnnotations;

namespace ComicBookCart_Master.Models
{
    public class Account
    {
        [Key]
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public int OrderID { get; set; }

        public string PaymentStatus { get; set; }

    }
}
