﻿using System.ComponentModel.DataAnnotations;

namespace ComicBookCart_Master.Models
{
    public class Order
    {
        [Key]
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public string ComicName { get; set; }
        public string ArtistName { get; set; }

    }
}
