﻿using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.DataAccessLAyer;
using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public class ComicRepository : IComicRepository
    {
        private readonly ComicBookDbContext _appDBContext;
        public ComicRepository(ComicBookDbContext context)
        {
            _appDBContext = context ??
                throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<Comics>> GetComics()
        {
            return await _appDBContext.Comics.ToListAsync();
            //throw new NotImplementedException();
        }
        public async Task<Comics> GetComicsByID(int ID)
        {
            return await _appDBContext.Comics.FindAsync(ID);
            //throw new NotImplementedException();
        }

        public async Task<Comics> InsertComics(Comics objComics)
        {
            _appDBContext.Comics.Add(objComics).State = EntityState.Added;
            await _appDBContext.SaveChangesAsync();
            return objComics;
            //throw new NotImplementedException();
        }

        public async Task<Comics> UpdateComics(Comics objComics)
        {
            _appDBContext.Entry(objComics).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objComics;
            //throw new NotImplementedException();
        }

        public bool DeleteComics(int ID)
        {
            bool result = false;
            var Comics = _appDBContext.Comics.Find(ID);
            if (Comics != null)
            {
                _appDBContext.Entry(Comics).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
            //throw new NotImplementedException();
        }

    }
}
