﻿using ComicBookCart_Master.Models;
namespace ComicBookCart_Master.Repository
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetOrders();
        Task<Order> GetOrderByID(int OrderID);
        Task<Order> InsertOrder(Order objOrder);
        Task<Order> UpdateOrder(Order objOrder);
        bool DeleteOrder(int OrderID);
    }
}
