﻿using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.DataAccessLAyer;
using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly ComicBookDbContext _appDBContext;
        public PaymentRepository(ComicBookDbContext context)
        {
            _appDBContext = context ??
                throw new ArgumentNullException(nameof(context));
        }
        public bool DeletePayment(int PaymentID)
        {
            bool result = false;
            var Payment = _appDBContext.Payment.Find(PaymentID);
            if (Payment != null)
            {
                _appDBContext.Entry(Payment).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
            throw new NotImplementedException();
        }

        public async Task<Payment> GetPaymentByID(int PaymentID)
        {
            return await _appDBContext.Payment.FindAsync(PaymentID);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Payment>> GetPayments()
        {
            return await _appDBContext.Payment.ToListAsync();
            throw new NotImplementedException();
        }

        public async Task<Payment> InsertPayment(Payment objPaymnet)
        {
            _appDBContext.Payment.Add(objPaymnet).State = EntityState.Added;
            await _appDBContext.SaveChangesAsync();
            return objPaymnet;
            throw new NotImplementedException();
        }

        public async Task<Payment> UpdatePayment(Payment objPayment)
        {
            _appDBContext.Entry(objPayment).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objPayment;
            throw new NotImplementedException();
        }
    }
}
