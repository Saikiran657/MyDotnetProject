﻿using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.DataAccessLAyer;
using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ComicBookDbContext _appDBContext;
        public OrderRepository(ComicBookDbContext context)
        {
            _appDBContext = context ??
                throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteOrder(int OrderID)
        {
            bool result = false;
            var Order = _appDBContext.Comics.Find(OrderID);
            if (Order != null)
            {
                _appDBContext.Entry(Order).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
            throw new NotImplementedException();
        }

        public async Task<Order> GetOrderByID(int OrderID)
        {
            return await _appDBContext.Order.FindAsync(OrderID);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Order>> GetOrders()
        {
            return await _appDBContext.Order.ToListAsync();
            throw new NotImplementedException();
        }

        public async Task<Order> InsertOrder(Order objOrder)
        {
            _appDBContext.Order.Add(objOrder).State = EntityState.Added;
            await _appDBContext.SaveChangesAsync();
            return objOrder;
            throw new NotImplementedException();
        }

        public async Task<Order> UpdateOrder(Order objOrder)
        {
            _appDBContext.Entry(objOrder).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objOrder;
            throw new NotImplementedException();
        }
    }
}
