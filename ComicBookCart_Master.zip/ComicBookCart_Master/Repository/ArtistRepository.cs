﻿using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.DataAccessLAyer;
using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public class ArtistRepository : IArtistRepository   
    {
        private readonly ComicBookDbContext _appDBContext;
        public ArtistRepository(ComicBookDbContext context)
        {
            _appDBContext = context ??
                throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteArtist(int ArtistID)
        {
            bool result = false;
            var Artist = _appDBContext.Artist.Find(ArtistID);
            if (Artist != null)
            {
                _appDBContext.Entry(Artist).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Artist>> GetArtist()
        {
            return await _appDBContext.Artist.ToListAsync();
            throw new NotImplementedException();
        }

        public async Task<Artist> GetArtistByID(int ArtistID)
        {
            return await _appDBContext.Artist.FindAsync(ArtistID);
            throw new NotImplementedException();
        }

        public async Task<Artist> InsertArtist(Artist objArtist)
        {
            _appDBContext.Artist.Add(objArtist).State = EntityState.Added;
            await _appDBContext.SaveChangesAsync();
            return objArtist;
            throw new NotImplementedException();
        }

        public async Task<Artist> UpdateArtist(Artist objArtist)
        {
            _appDBContext.Entry(objArtist).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objArtist;
            throw new NotImplementedException();
        }
    }
}
