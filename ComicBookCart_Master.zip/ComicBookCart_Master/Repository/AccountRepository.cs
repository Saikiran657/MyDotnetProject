﻿using Microsoft.EntityFrameworkCore;
using ComicBookCart_Master.DataAccessLAyer;
using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public class AccountRepository : IAccountRepository
    {
        private readonly ComicBookDbContext _appDBContext;
        public AccountRepository(ComicBookDbContext context)
        {
            _appDBContext = context ??
                throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteAccount(int CustomerID)
        {
            bool result = false;
            var Account = _appDBContext.Comics.Find(CustomerID);
            if (Account != null)
            {
                _appDBContext.Entry(Account).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
            //throw new NotImplementedException();
        }

        public async Task<Account> GetAccountByID(int CustomerID)
        {
            return await _appDBContext.Account.FindAsync(CustomerID);
            throw new NotImplementedException();
        }



        //GetAccountDetails
        public async Task<IEnumerable<Account>> GetAccountDetails()
        {
            return await _appDBContext.Account.ToListAsync();
            //throw new NotImplementedException();
        }

        

        public async Task<Account> InsertAccount(Account objAccount)
        {
            _appDBContext.Account.Add(objAccount).State = EntityState.Added;
            await _appDBContext.SaveChangesAsync();
            return objAccount;
            //throw new NotImplementedException();
        }

        public async Task<Account> UpdateAccount(Account objAccount)
        {
            _appDBContext.Entry(objAccount).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objAccount;
            throw new NotImplementedException();
        }
    }
}
