﻿using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public interface IComicRepository
    {
        Task<IEnumerable<Comics>>GetComics();
        Task<Comics> GetComicsByID(int ID);
        Task<Comics> InsertComics(Comics objComics);
        Task<Comics> UpdateComics(Comics objComics);
        bool DeleteComics(int ID);
    }
}
