﻿using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public interface IArtistRepository
    {
        Task<IEnumerable<Artist>> GetArtist();
        Task<Artist> GetArtistByID(int ArtistID);
        Task<Artist> InsertArtist(Artist objArtist);
        Task<Artist> UpdateArtist(Artist objArtist);
        bool DeleteArtist(int ArtistID);
    }
}
