﻿using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public interface IPaymentRepository
    {
       
            Task<IEnumerable<Payment>> GetPayments();
            Task<Payment> GetPaymentByID(int PaymentID);
            Task<Payment> InsertPayment(Payment objPaymnet);
            Task<Payment> UpdatePayment(Payment objPayment);
            bool DeletePayment(int PaymentID);
        }}

