﻿using ComicBookCart_Master.Models;

namespace ComicBookCart_Master.Repository
{
    public interface IAccountRepository
    {
        Task<IEnumerable<Account>> GetAccountDetails();

        Task<Account> GetAccountByID( int CustomerID);     
        Task<Account> InsertAccount(Account objAccount);
        Task<Account> UpdateAccount(Account objAccount);
        bool DeleteAccount(int CustomerID);
    }
}
