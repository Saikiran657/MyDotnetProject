﻿namespace ConsumingAPI__TO_MVC.Models
{
    public class Order
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public string? ComicName { get; set; }
        public string? ArtistName { get; set; }
    }
}
