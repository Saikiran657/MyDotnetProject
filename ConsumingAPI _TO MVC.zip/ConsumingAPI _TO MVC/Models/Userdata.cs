﻿namespace ConsumingAPI__TO_MVC.Models
{
    public class Userdata
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }
}
