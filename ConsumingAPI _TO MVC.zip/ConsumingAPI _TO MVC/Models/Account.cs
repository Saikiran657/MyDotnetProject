﻿namespace ConsumingAPI__TO_MVC.Models
{
    public class Account
    {
       
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public int OrderID { get; set; }

        public string PaymentStatus { get; set; }
    }
}
