﻿namespace ConsumingAPI__TO_MVC.Models
{
    public class Payment
    {
        public int PaymentID { get; set; }
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
    }
}
