﻿using Microsoft.AspNetCore.Mvc;
using ConsumingAPI__TO_MVC.Models;


namespace ConsumingAPI__TO_MVC.Controllers
{
    public class ComicController : Controller
    {
        HttpClient client;
        HttpResponseMessage response;
        List<Comics> Comics1 = new List<Comics>();
       
        public ActionResult GetComics()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7199");
            response = client.GetAsync("api/Comics/GetComics/").Result;
            var Comics = response.Content.ReadAsAsync<IEnumerable<Comics>>().Result;
            foreach (var c in Comics)
            {
                Comics Com = new Comics();
                Com.ID = c.ID;
                Com.Name = c.Name;
                Com.Number_of_Episodes = c.Number_of_Episodes;
                Com.Series_Title = c.Series_Title;
                Com.ArtistID = c.ArtistID;

                Comics1.Add(Com);

            }
            //cvm.MyComics = Comics1;
            return View(Comics1);
        }
        //public ActionResult CreateNew()
        //{
        //    client = new HttpClient();
        //    client.BaseAddress = new Uri("https://localhost:7119");
        //    response = client.GetAsync("api/Comics/AddComics/").Result;
        //    //var Comics = response.Content.ReadAsAsync<objComics>().Result;
        //    //return View(Comics);
        //}


    }

}
