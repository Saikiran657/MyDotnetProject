﻿using ConsumingAPI__TO_MVC.Models;
//using Google.Protobuf.WellKnownTypes;
using Microsoft.AspNetCore.Mvc;

namespace ConsumingAPI__TO_MVC.Controllers
{
    public class ArtistController : Controller
    {
        HttpClient client;
        HttpResponseMessage response;
        List<Artist> Artists = new List<Artist>();
        public ActionResult GetArtist()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7199");
            response = client.GetAsync("/api/Artists/GetArtist").Result;
            var Artist = response.Content.ReadAsAsync<IEnumerable<Artist>>().Result;
            foreach (var a in Artist)
            {
                Artist Art = new Artist();
                Art.ArtistID = a.ArtistID;
                Art.ArtistName = a.ArtistName;
                Art.ArtistRole =a.ArtistRole;
               

                Artists.Add(Art);

            }
            //cvm.MyComics = Comics1;
            return View(Artists);
        }
    }
}
