﻿using Microsoft.AspNetCore.Mvc;
using ConsumingAPI__TO_MVC.Models;

namespace ConsumingAPI__TO_MVC.Controllers
{
    public class OrderController : Controller
    {

        HttpClient client;
        HttpResponseMessage response;
        List<Order> Order1 = new List<Order>();
        public ActionResult GetOrder()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7199");
            response = client.GetAsync("api/Order/GetOrders/").Result;
            var Order = response.Content.ReadAsAsync<IEnumerable<Order>>().Result;
            foreach (var o in Order)
            {
                Order ord = new Order();
                ord.OrderID = o.OrderID;
                ord.CustomerID = o.CustomerID;
                ord.ComicName = o.ComicName;
                ord.ArtistName = o.ArtistName;


                Order1.Add(ord);

            }
            return View(Order1);
        }
    }
}
