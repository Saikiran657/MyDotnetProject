﻿using ConsumingAPI__TO_MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace ConsumingAPI__TO_MVC.Controllers
{
    public class PaymentController : Controller
    {
        HttpClient client;
        HttpResponseMessage response;
        List<Payment> Payment1 = new List<Payment>();
        public ActionResult GetPayments()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7199");
            response = client.GetAsync("api/Payment/GetPayments").Result;
            var Payment = response.Content.ReadAsAsync<IEnumerable<Payment>>().Result;
            foreach (var p in Payment)
            {
                Payment pay = new Payment();
                pay.PaymentID = p.PaymentID;
                pay.CustomerID = p.CustomerID;
                pay.CustomerName = p.CustomerName;
               


                Payment1.Add(pay);

            }
            return View(Payment1);
        }
        //[HttpPost]
        //public ActionResult AddPayments()
        //{
        //    client = new HttpClient();
        //    client.BaseAddress = new Uri("https://localhost:7119");
        //    response = client.GetAsync("api/Payment/AddPayments").Result;
        //    var Payment = response.Content.ReadAsAsync<Payment>>().Result;

        //}

    }
}
