﻿using Microsoft.AspNetCore.Mvc;

namespace ConsumingAPI__TO_MVC.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Signup()
        {
            return RedirectToAction("Login");
        }
    }
}
