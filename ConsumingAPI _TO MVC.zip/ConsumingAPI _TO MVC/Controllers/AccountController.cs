﻿using ConsumingAPI__TO_MVC.Models;
using Microsoft.AspNetCore.Mvc;


namespace ConsumingAPI__TO_MVC.Controllers
{
    public class AccountController : Controller
    {

        HttpClient client;
        HttpResponseMessage response;
        List<Account> Account1 = new List<Account>();

        public ActionResult GetAccount()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7199");
            response = client.GetAsync("api/Account/GetAccountDetails/").Result;
            var Account = response.Content.ReadAsAsync<IEnumerable<Account>>().Result;
            foreach (var ac in Account)
            {
                Account acc = new Account();
                acc.CustomerID = ac.CustomerID;
                acc.CustomerName = ac.CustomerName;
                acc.OrderID= ac.OrderID;    
                acc.PaymentStatus = ac.PaymentStatus;


                Account1.Add(acc);

            }
            //cvm.MyComics = Comics1;
            return View(Account1);
        }
    }
}
